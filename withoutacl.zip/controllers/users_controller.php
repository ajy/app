<?php
class UsersController extends AppController {

	var $name = 'Users';
	
	var $components = array('Email','Tickets');
	
	function login() {
	
	}
	
	function logout() {
		$this->redirect($this->Auth->logout());
	}
	
	function testMail($username) {
		$User = $this->User->read(null,$username);
		$this->Email->from = "tester.com";
		$this->Email->to = $User['email'];
		$this->Email->subject = "test";
		$this->Email->delivery = 'debug';
		$this->Email->template = "test_message";
		$this->Email->sendAs = 'both';
		$this->set('username', $User['username']);
		$this->Email->send();		
	}
	
	function sendPasswordResetMail() 
    { 
        if (!empty($this->params['data'])) 
        { 
            $theUser = $this->User->findByEmail($this->params['data']['User']['email']); 
             
            if(is_array($theUser) && is_array($theUser['User'])) 
            { 
                $ticket = $this->Tickets->set($theUser['User']['email']); 

                $to      = $theUser['User']['email']; // users email 
                $subject = utf8_decode('Password reset information'); 
                $message = 'http://'.$_SERVER['SERVER_NAME'].'/'.$this->params['controller'].'/password/'.$ticket; 
                $from    = 'noreply@example.com'; 
                $headers = 'From: ' . $from . "\r\n" . 
                   'Reply-To: ' . $from . "\r\n" . 
                   'X-Mailer: CakePHP PHP ' . phpversion(). "\r\n" . 
                   'Content-Type: text/plain; charset=ISO-8859-1'; 
                 
                   if(mail($to, $subject, utf8_decode( sprintf($this->Lang->show('recover_email'), $message) ."\r\n"."\r\n" ), $headers)) 
                { 
                    $this->set('message', 'A recovery email was sent. Check your inbox.'); 
                }else{ 
                    // internal error, sorry 
                    $this->set('message', 'Server error, please try again later.'); 
                } 
            }else{ 
                // no user found for adress 
                $this->set('message', 'No user with that email address'); 
            } 
        } 
    } 


// uses the ticket to reset the password for the correct user. 
    function password($hash = null) 
    { 
        if ( $email = $this->Tickets->get($this->params['controller'], $hash) ) 
        { 
            $authUser = $this->User->findByEmail($email); 
            if (is_array($authUser)) 
            { 
                if (!empty($this->params['data'])) 
                { 
                    $theUser = $this->User->findById($this->params['data']['User']['id']); 

                    if ($this->User->save($this->params['data'])) 
                    { 
                        $this->set('message', 'Your new password was saved.'); 
                    }else{ 
                        $this->set('message', 'User could not be saved'); 
                    } 
                    $this->Tickets->del($hash); 
                    $this->redirect( '/' ); 
                } 
                unset($authUser['User']['pass']); 
                $this->params['data'] = $authUser; 
                $this->render(); 
                return; 
            } 
        } 
        $this->Tickets->del($hash); 
        $this->set('message', 'No hash provided'); 
        $this->redirect( '/' );     
    }
    	
	function index() {
		$this->User->recursive = 0;
		$this->set('users', $this->paginate());
	}

	function view($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid user', true));
			$this->redirect(array('action' => 'index'));
		}
		$this->set('user', $this->User->read(null, $id));
	}

	function add() {
		if (!empty($this->data)) {
			$this->User->create();
			if ($this->User->save($this->data)) {
				$this->Session->setFlash(__('The user has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The user could not be saved. Please, try again.', true));
			}
		}
		$groups = $this->User->Group->find('list');
		$this->set(compact('groups'));
	}

	function edit($id = null) {
		if (!$id && empty($this->data)) {
			$this->Session->setFlash(__('Invalid user', true));
			$this->redirect(array('action' => 'index'));
		}
		if (!empty($this->data)) {
			if ($this->User->save($this->data)) {
				$this->Session->setFlash(__('The user has been saved', true));
				$this->redirect(array('action' => 'index'));
			} else {
				$this->Session->setFlash(__('The user could not be saved. Please, try again.', true));
			}
		}
		if (empty($this->data)) {
			$this->data = $this->User->read(null, $id);
		}
		$groups = $this->User->Group->find('list');
		$this->set(compact('groups'));
	}

	function delete($id = null) {
		if (!$id) {
			$this->Session->setFlash(__('Invalid id for user', true));
			$this->redirect(array('action'=>'index'));
		}
		if ($this->User->delete($id)) {
			$this->Session->setFlash(__('User deleted', true));
			$this->redirect(array('action'=>'index'));
		}
		$this->Session->setFlash(__('User was not deleted', true));
		$this->redirect(array('action' => 'index'));
	}
	
	function setDefaultPermissions() {
		$group =& $this->User->Group;
		$originalGroupId = $group->id;
		
		//allow admins to everything
		$group->id = 1;
		$this->Acl->allow($group,'controllers');
				
		//set teachers access
		$group->id = 2;
		$this->Acl->deny($group,'controllers');
		$this->Acl->allow($group, 'controllers/Comments/index');
		$this->Acl->allow($group, 'controllers/Comments/view');
		$this->Acl->allow($group, 'controllers/FormARecords/index');
		$this->Acl->allow($group, 'controllers/FormARecords/view');
		$this->Acl->allow($group, 'controllers/FormBRecords/index');
		$this->Acl->allow($group, 'controllers/FormBRecords/view');
		$this->Acl->allow($group, 'controllers/Subjects/index');
		$this->Acl->allow($group, 'controllers/Subjects/view');
		$this->Acl->allow($group, 'controllers/Users/login');
		$this->Acl->allow($group, 'controllers/Users/logout');
		//set students access
		$group->id = 3;
		$this->Acl->deny($group, 'controllers');
		$this->Acl->allow($group, 'controllers/Comments/add');
		$this->Acl->allow($group, 'controllers/FormARecords/add');
		$this->Acl->allow($group, 'controllers/FormBRecords/add');
		$this->Acl->allow($group, 'controllers/Users/login');
		$this->Acl->allow($group, 'controllers/Users/logout');
								
		echo('all done');
		exit;		
	} 
}
